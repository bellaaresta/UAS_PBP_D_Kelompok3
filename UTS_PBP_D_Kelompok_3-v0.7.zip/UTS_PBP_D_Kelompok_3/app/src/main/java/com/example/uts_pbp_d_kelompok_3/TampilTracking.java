package com.example.uts_pbp_d_kelompok_3;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import com.example.uts_pbp_d_kelompok_3.Model.Delivery;
import com.example.uts_pbp_d_kelompok_3.Model.History;
import com.example.uts_pbp_d_kelompok_3.databinding.TrackingLayoutBinding;

import java.util.ArrayList;

public class TampilTracking extends AppCompatActivity {
    public static final String DELIVERY = "delivery";
    public static final String HISTORIES = "histories";
    private TrackingLayoutBinding binding;
    private TrackingPreferences trackingPreferences;
    private Delivery delivery;
    private ArrayList<History> histories = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.tracking_layout);

        if (!getIntent().hasExtra(DELIVERY)) {
            finish();
        }
        delivery = getIntent().getParcelableExtra(DELIVERY);
        histories = getIntent().getParcelableArrayListExtra(HISTORIES);

        binding.textResi.setText("Nomor Resi #" + delivery.getResi());
        binding.tanggal.setText(delivery.getDate());
        if (histories != null) {
            binding.status.setText(histories.get(histories.size() - 1).getStatus());
            for (History history : histories) {
                TextView textView = new TextView(this);
                textView.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
                textView.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                textView.setText(history.getDate() + " \n" + history.getStatus());
                binding.layoutHistory.addView(textView);
            }
        }

        binding.btnlogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(TampilTracking.this, MainActivity.class));
                finish();
            }
        });

        binding.btnGeolocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(TampilTracking.this, MapsActivity.class));
            }
        });
    }

}