//package com.example.uts_pbp_d_kelompok_3.Databinding;
//
//import java.util.ArrayList;
//
//public class DaftarKita{
//    public ArrayList<DataKita> DataKita;
//    public DaftarKita()
//    {
//        DataKita = new ArrayList();
//        DataKita.add(brijit);
//        DataKita.add(bella);
//        DataKita.add(agi);
//
//    }
//
//    public static final DataKita brijit = new DataKita("Brigita Angga Permata A", "190710126","");
//
//    public static final DataKita bella = new DataKita("Bella Arista Kadang", "190710372", "");
//
//    public static final DataKita agi= new DataKita("Agi Fransiska", "190710411","");
//
//    }