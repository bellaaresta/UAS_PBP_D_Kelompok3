package com.example.uts_pbp_d_kelompok_3;

public class Tracking {
    private String NoResi;

    public Tracking(String NoResi)
    {
        this.NoResi = NoResi;
    }

    public String getNoResi(){
        return NoResi;
    }

    public void setNoResi(String NoResi){
        this.NoResi = NoResi;
    }
}
