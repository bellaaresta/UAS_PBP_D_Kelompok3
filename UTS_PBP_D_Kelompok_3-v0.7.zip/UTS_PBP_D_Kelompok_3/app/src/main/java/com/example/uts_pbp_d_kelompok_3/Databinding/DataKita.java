//package com.example.uts_pbp_d_kelompok_3.Databinding;
//
//public class DataKita {
//    public String nama;
//    public String npm;
//    public String pic;
//    //public DataKita() {}
//
//    public DataKita(String nama, String npm, String pic)
//    {
//        this.nama = nama;
//        this.npm = npm;
//        this.pic = pic;
//    }
//
//    public String getNama() {return nama;}
//
//    public void setNama(String nama) {this.nama = nama;}
//
//
//    public String getNPM() {return npm;}
//
//    public void setNPM(String npm) {this.npm = npm;}
//
//    public String getPic() {return pic;}
//
//    public void setImgUrl(String imgURL) {this.pic = imgURL;}
//
//
//
//
//}
