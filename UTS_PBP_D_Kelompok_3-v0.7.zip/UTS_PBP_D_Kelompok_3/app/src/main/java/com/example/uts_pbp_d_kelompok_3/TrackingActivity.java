package com.example.uts_pbp_d_kelompok_3;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.databinding.DataBindingUtil;

import com.example.uts_pbp_d_kelompok_3.Model.Delivery;
import com.example.uts_pbp_d_kelompok_3.databinding.ActivityCekresiBinding;
import com.example.uts_pbp_d_kelompok_3.network.ApiClient;
import com.example.uts_pbp_d_kelompok_3.network.ApiInterface;
import com.example.uts_pbp_d_kelompok_3.network.Response;

import retrofit2.Call;
import retrofit2.Callback;

public class TrackingActivity extends AppCompatActivity {
    private ActivityCekresiBinding binding;
    private Delivery delivery;
//    private TrackingPreferences trackingPreferences;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = DataBindingUtil.setContentView(this, R.layout.activity_cekresi);

//        trackingPreferences = new TrackingPreferences(TrackingActivity.this);

        binding.btnCek.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (validateForm()) {
                    String resi = binding.NoResi.getText().toString().trim();
                    ApiInterface apiInterface = ApiClient.getClient().create(ApiInterface.class);
                    Call<Response<Delivery>> call = apiInterface.detail(resi);
                    call.enqueue(new Callback<Response<Delivery>>() {
                        @Override
                        public void onResponse(Call<Response<Delivery>> call, retrofit2.Response<Response<Delivery>> response) {
                            if (response.isSuccessful() && response.body() != null && response.body().getStatus().equalsIgnoreCase("success")) {
                                Intent intent = new Intent(TrackingActivity.this, TampilTracking.class);
                                intent.putExtra(TampilTracking.DELIVERY, response.body().getData());
                                intent.putExtra(TampilTracking.HISTORIES, response.body().getData().getHistories());
                                startActivity(intent);
                            } else {
                                Toast.makeText(TrackingActivity.this, "Tidak ditemukan", Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onFailure(Call<Response<Delivery>> call, Throwable t) {
                            Toast.makeText(TrackingActivity.this, "Tidak ditemukan", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        });
    }

    private boolean validateForm() {
        if (binding.NoResi.getText().toString().trim().isEmpty()) {
            Toast.makeText(TrackingActivity.this, "Resi Kosong", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }
}
